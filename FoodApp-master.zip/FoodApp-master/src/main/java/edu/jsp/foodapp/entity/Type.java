package edu.jsp.foodapp.entity;

public enum Type {
	VEG, NON_VEG, EGGETARIAN, BREAKFAST, LUNCH, DINNER, SNACKS;
}
