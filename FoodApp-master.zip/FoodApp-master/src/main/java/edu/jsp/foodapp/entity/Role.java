package edu.jsp.foodapp.entity;

public enum Role {
	ADMIN, MANAGER, STAFF, CHEF, CUSTOMER;
}
