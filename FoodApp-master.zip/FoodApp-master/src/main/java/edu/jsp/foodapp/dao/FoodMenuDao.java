package edu.jsp.foodapp.dao;

import edu.jsp.foodapp.entity.FoodMenu;

public class FoodMenuDao {

	public void saveFoodMenu(FoodMenu foodMenu) {

	}

	public void findFoodMenuById(long foodMenuID) {

	}

	public void findAllFoodMenu() {

	}

	public void removeFoodMenuById(long foodMenuById) {

	}
}
