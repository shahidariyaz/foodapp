package edu.jsp.foodapp.dao;

import edu.jsp.foodapp.entity.FoodOrder;

public class FoodOrderDao {

	public void saveFoodOrder(FoodOrder foodOrder) {

	}

	public void findFoodOrderById(long foodOrderId) {

	}

	public void findAllFoodOrder() {

	}

	public void removeFoodOrderById(long foodOrderId) {

	}
}
