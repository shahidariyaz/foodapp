package edu.jsp.foodapp.entity;

public enum Status {

	RECIVED, PREPRING, READYTOSERVE,DELIVERED;
}
